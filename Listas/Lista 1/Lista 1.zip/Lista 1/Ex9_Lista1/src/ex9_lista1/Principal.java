package ex9_lista1;

public class Principal {

	public static void main(String[] args) {
		
		Computador c = new Computador();
		c.setNome("comp1").setMarca("Intel").setData(1,1,2001);

	}
}