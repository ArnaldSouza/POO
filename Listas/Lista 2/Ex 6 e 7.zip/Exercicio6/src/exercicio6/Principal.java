
package exercicio6;

public class Principal {

    public class ExceptionA extends Exception {
    
    }
    
    public class ExceptionB extends ExceptionA {
    
    }

    public class ExceptionC extends ExceptionB {
        
    }       
    
    public static void main(String[] args) {
        
    }
    
}
