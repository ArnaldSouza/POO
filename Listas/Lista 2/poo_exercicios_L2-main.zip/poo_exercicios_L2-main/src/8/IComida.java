package poo_exercicios_l2;

public interface IComida{
	public float getCalorias();
	public String getNome();
	public float conversaoCaloriasParaG();
}